const FALLBACK_EXERCISES = [
  { id: "Barbell_Bench_Press_-_Medium_Grip", name: "Supino Reto com Barra", force: "push", level: "iniciante", mechanic: "composto", equipment: "barra", primaryMuscles: ["peito"], secondaryMuscles: ["ombros", "triceps"], instructions: ["Deite-se em um banco reto com pegada na largura dos ombros.", "Desça a barra lentamente até tocar o meio do peito.", "Empurre de volta à posição inicial."], category: "forca" },
  { id: "Incline_Dumbbell_Press", name: "Supino Inclinado com Halteres", force: "push", level: "iniciante", mechanic: "composto", equipment: "halteres", primaryMuscles: ["peito"], secondaryMuscles: ["ombros", "triceps"], instructions: ["Deite-se no banco inclinado a 30-45 graus.", "Empurre os halteres acima do peito e retorne com controle."], category: "forca" },
  { id: "Butterfly", name: "Peck Deck / Voador na Máquina", force: "pull", level: "iniciante", mechanic: "isolado", equipment: "maquina", primaryMuscles: ["peito"], secondaryMuscles: [], instructions: ["Sente-se com as costas apoiadas e feche os braços à frente."], category: "forca" },
  { id: "Cable_Crossover", name: "Crossover na Polia", force: "push", level: "iniciante", mechanic: "isolado", equipment: "cabo", primaryMuscles: ["peito"], secondaryMuscles: ["ombros"], instructions: ["Ajuste as polias altas e dê um passo à frente.", "Feche os braços à frente contraindo o peitoral."], category: "forca" },
  { id: "Bench_Press_-_With_Bands", name: "Supino com Faixas Elásticas", force: "push", level: "iniciante", mechanic: "composto", equipment: "faixas", primaryMuscles: ["peito"], secondaryMuscles: ["ombros", "triceps"], instructions: ["Prenda a faixa sob o banco e empurre as alças para cima."], category: "forca" },
  { id: "Incline_Push-Up_Medium", name: "Flexão Inclinada", force: "push", level: "iniciante", mechanic: "composto", equipment: "peso-do-corpo", primaryMuscles: ["peito"], secondaryMuscles: ["ombros", "triceps"], instructions: ["Apoie as mãos em um banco firme.", "Desça o peito até a borda e empurre de volta."], category: "forca" },
  { id: "Close-Grip_Front_Lat_Pulldown", name: "Pulldown Frente na Polia", force: "pull", level: "iniciante", mechanic: "composto", equipment: "cabo", primaryMuscles: ["dorsais"], secondaryMuscles: ["biceps", "meio-das-costas"], instructions: ["Segure a barra na polia alta.", "Puxe até a parte superior do peito retraindo as escápulas."], category: "forca" },
  { id: "Chin-Up", name: "Barra Fixa Supinada (Chin-Up)", force: "pull", level: "iniciante", mechanic: "composto", equipment: "peso-do-corpo", primaryMuscles: ["dorsais"], secondaryMuscles: ["biceps"], instructions: ["Segure a barra com palmas voltadas para você.", "Puxe o tronco até passar o queixo da barra."], category: "forca" },
  { id: "Bent_Over_Barbell_Row", name: "Remada Curvada com Barra", force: "pull", level: "iniciante", mechanic: "composto", equipment: "barra", primaryMuscles: ["meio-das-costas"], secondaryMuscles: ["biceps", "dorsais"], instructions: ["Incline o tronco mantendo a coluna neutra.", "Puxe a barra em direção ao abdômen."], category: "forca" },
  { id: "Bent_Over_Two-Dumbbell_Row", name: "Remada Curvada com Halteres", force: "pull", level: "iniciante", mechanic: "composto", equipment: "halteres", primaryMuscles: ["meio-das-costas"], secondaryMuscles: ["biceps", "dorsais"], instructions: ["Com um halter em cada mão, incline o tronco.", "Puxe os halteres mantendo os cotovelos próximos ao corpo."], category: "forca" },
  { id: "Alternating_Kettlebell_Row", name: "Remada Alternada com Kettlebell", force: "pull", level: "intermediario", mechanic: "isolado", equipment: "kettlebell", primaryMuscles: ["meio-das-costas"], secondaryMuscles: ["biceps", "dorsais"], instructions: ["Incline o tronco e puxe um kettlebell por vez em direção às costelas."], category: "forca" },
  { id: "Barbell_Full_Squat", name: "Agachamento Livre com Barra", force: "push", level: "intermediario", mechanic: "composto", equipment: "barra", primaryMuscles: ["quadriceps"], secondaryMuscles: ["gluteos", "isquiotibiais"], instructions: ["Apoie a barra nos trapézios.", "Agache mantendo o tronco firme e suba empurrando pelos calcanhares."], category: "forca" },
  { id: "Hack_Squat", name: "Agachamento Hack na Máquina", force: "push", level: "iniciante", mechanic: "composto", equipment: "maquina", primaryMuscles: ["quadriceps"], secondaryMuscles: ["gluteos", "isquiotibiais"], instructions: ["Apoie as costas no encosto e os ombros nas almofadas.", "Agache até 90 graus e empurre com os calcanhares."], category: "forca" },
  { id: "Dumbbell_Squat", name: "Agachamento com Halteres", force: "push", level: "iniciante", mechanic: "composto", equipment: "halteres", primaryMuscles: ["quadriceps"], secondaryMuscles: ["gluteos", "isquiotibiais"], instructions: ["Segure um halter em cada mão ao lado do corpo.", "Agache até as coxas ficarem paralelas ao chão."], category: "forca" },
  { id: "Goblet_Squat", name: "Agachamento Goblet com Kettlebell", force: "push", level: "iniciante", mechanic: "composto", equipment: "kettlebell", primaryMuscles: ["quadriceps"], secondaryMuscles: ["gluteos", "isquiotibiais"], instructions: ["Segure o kettlebell junto ao peito e agache entre as pernas."], category: "forca" },
  { id: "Bodyweight_Squat", name: "Agachamento Livre Corporal", force: "push", level: "iniciante", mechanic: "composto", equipment: "peso-do-corpo", primaryMuscles: ["quadriceps"], secondaryMuscles: ["gluteos", "isquiotibiais"], instructions: ["Pés na largura dos ombros.", "Agache mantendo o peito aberto e joelhos alinhados."], category: "forca" },
  { id: "Ball_Leg_Curl", name: "Flexão de Pernas na Bola", force: "pull", level: "iniciante", mechanic: "isolado", equipment: "bola-de-exercicio", primaryMuscles: ["isquiotibiais"], secondaryMuscles: ["gluteos"], instructions: ["Apoie os calcanhares na bola e eleve o quadril.", "Flexione os joelhos trazendo a bola para perto."], category: "forca" },
  { id: "Glute_Ham_Raise", name: "Mesa / Flexão Posterior na Máquina", force: "pull", level: "intermediario", mechanic: "composto", equipment: "maquina", primaryMuscles: ["isquiotibiais"], secondaryMuscles: ["gluteos"], instructions: ["Prenda os tornozelos no suporte.", "Controle a descida e suba contraindo posteriores."], category: "powerlifting" },
  { id: "Barbell_Hip_Thrust", name: "Elevação Pélvica com Barra", force: "push", level: "intermediario", mechanic: "composto", equipment: "barra", primaryMuscles: ["gluteos"], secondaryMuscles: ["isquiotibiais"], instructions: ["Apoie as escápulas no banco e a barra sobre o quadril.", "Eleve o quadril até alinhar tronco e coxas."], category: "powerlifting" },
  { id: "Butt_Lift_Bridge", name: "Ponte de Glúteos no Solo", force: "push", level: "iniciante", mechanic: "isolado", equipment: "peso-do-corpo", primaryMuscles: ["gluteos"], secondaryMuscles: ["isquiotibiais"], instructions: ["Deite-se de costas com joelhos flexionados.", "Eleve o quadril contraindo os glúteos no topo."], category: "forca" },
  { id: "Hip_Lift_with_Band", name: "Elevação de Quadril com Faixa", force: "push", level: "iniciante", mechanic: "composto", equipment: "faixas", primaryMuscles: ["gluteos"], secondaryMuscles: ["isquiotibiais"], instructions: ["Posicione a faixa sobre o quadril e empurre com os calcanhares."], category: "powerlifting" },
  { id: "Dumbbell_Shoulder_Press", name: "Desenvolvimento de Ombros com Halteres", force: "push", level: "intermediario", mechanic: "composto", equipment: "halteres", primaryMuscles: ["ombros"], secondaryMuscles: ["triceps"], instructions: ["Sentado, empurre os halteres acima da cabeça.", "Retorne até a altura do queixo com controle."], category: "forca" },
  { id: "Face_Pull", name: "Face Pull na Polia", force: "pull", level: "intermediario", mechanic: "composto", equipment: "cabo", primaryMuscles: ["ombros"], secondaryMuscles: ["meio-das-costas"], instructions: ["Puxe a corda em direção ao rosto abrindo os cotovelos."], category: "forca" },
  { id: "Barbell_Curl", name: "Rosca Direta com Barra", force: "pull", level: "iniciante", mechanic: "isolado", equipment: "barra", primaryMuscles: ["biceps"], secondaryMuscles: ["antebracos"], instructions: ["Flexione os cotovelos mantendo-os fixos ao lado do corpo."], category: "forca" },
  { id: "Alternate_Hammer_Curl", name: "Rosca Martelo Alternada", force: "pull", level: "iniciante", mechanic: "isolado", equipment: "halteres", primaryMuscles: ["biceps"], secondaryMuscles: ["antebracos"], instructions: ["Com pegada neutra, flexione um braço de cada vez."], category: "forca" },
  { id: "Dip_Machine", name: "Tríceps Mergulho na Máquina", force: "push", level: "iniciante", mechanic: "composto", equipment: "maquina", primaryMuscles: ["triceps"], secondaryMuscles: ["peito", "ombros"], instructions: ["Empurre as alças para baixo mantendo os cotovelos próximos ao tronco."], category: "forca" },
  { id: "Cable_Rope_Overhead_Triceps_Extension", name: "Tríceps Corda Acima da Cabeça", force: "push", level: "iniciante", mechanic: "isolado", equipment: "cabo", primaryMuscles: ["triceps"], secondaryMuscles: [], instructions: ["Estenda os cotovelos acima da cabeça mantendo-os fechados."], category: "forca" },
  { id: "Bench_Dips", name: "Mergulho no Banco", force: "push", level: "iniciante", mechanic: "composto", equipment: "peso-do-corpo", primaryMuscles: ["triceps"], secondaryMuscles: ["peito", "ombros"], instructions: ["Apoie as mãos no banco atrás do corpo e flexione os cotovelos a 90 graus."], category: "forca" },
  { id: "Calf_Press_On_The_Leg_Press_Machine", name: "Panturrilha no Leg Press", force: "push", level: "iniciante", mechanic: "isolado", equipment: "maquina", primaryMuscles: ["panturrilhas"], secondaryMuscles: [], instructions: ["Apoie a ponta dos pés na base da plataforma e faça flexão plantar."], category: "forca" },
  { id: "Calf_Raises_-_With_Bands", name: "Elevação de Panturrilha com Faixa", force: "push", level: "iniciante", mechanic: "isolado", equipment: "faixas", primaryMuscles: ["panturrilhas"], secondaryMuscles: [], instructions: ["Pise na faixa, segure as alças nos ombros e suba na ponta dos pés."], category: "forca" },
  { id: "Ab_Crunch_Machine", name: "Abdominal na Máquina", force: "pull", level: "intermediario", mechanic: "isolado", equipment: "maquina", primaryMuscles: ["abdominais"], secondaryMuscles: [], instructions: ["Flexione o tronco contra a resistência da máquina expirando."], category: "forca" },
  { id: "Dead_Bug", name: "Inseto Morto (Dead Bug)", force: "pull", level: "iniciante", mechanic: "composto", equipment: "peso-do-corpo", primaryMuscles: ["abdominais"], secondaryMuscles: [], instructions: ["Mantenha a lombar pressionada no solo e alterne extensão de perna e braço opostos."], category: "forca" },
  { id: "Cable_Crunch", name: "Abdominal na Polia Alta", force: "pull", level: "iniciante", mechanic: "isolado", equipment: "cabo", primaryMuscles: ["abdominais"], secondaryMuscles: [], instructions: ["Ajoelhe-se sob a polia e flexione a coluna contraindo o abdômen."], category: "forca" }
];

const NOMES_DIAS = ["Dia 1", "Dia 2", "Dia 3", "Dia 4", "Dia 5", "Dia 6", "Dia 7"];

// Catálogo de modelos de divisão disponíveis conforme a frequência (1 a 7 dias)
const MODELOS_DIVISAO = {
  1: [
    {
      id: "fb_1",
      label: "Full Body Completo (1x/sem)",
      dias: [
        { nome: "Dia 1 · Full Body Completo", grupos: ["quadriceps", "peito", "dorsais", "isquiotibiais", "ombros", "abdominais"] }
      ]
    }
  ],
  2: [
    {
      id: "fb_2",
      label: "Full Body A / B (Corpo Todo 2x)",
      dias: [
        { nome: "Dia 1 · Full Body A (Ênfase Anterior)", grupos: ["quadriceps", "peito", "dorsais", "ombros", "abdominais"] },
        { nome: "Dia 2 · Full Body B (Ênfase Posterior)", grupos: ["isquiotibiais", "gluteos", "meio-das-costas", "biceps", "triceps", "panturrilhas"] }
      ]
    },
    {
      id: "ul_2",
      label: "Upper / Lower (Superiores & Inferiores)",
      dias: [
        { nome: "Dia 1 · Superiores (Upper)", grupos: ["peito", "dorsais", "meio-das-costas", "ombros", "biceps", "triceps"] },
        { nome: "Dia 2 · Inferiores & Core (Lower)", grupos: ["quadriceps", "isquiotibiais", "gluteos", "panturrilhas", "abdominais"] }
      ]
    }
  ],
  3: [
    {
      id: "ppl_3",
      label: "Push / Pull / Legs (Empurrar, Puxar, Pernas)",
      dias: [
        { nome: "Dia 1 · Empurrar (Push)", grupos: ["peito", "ombros", "triceps"] },
        { nome: "Dia 2 · Puxar (Pull)", grupos: ["dorsais", "meio-das-costas", "biceps", "antebracos"] },
        { nome: "Dia 3 · Pernas & Core (Legs)", grupos: ["quadriceps", "isquiotibiais", "gluteos", "panturrilhas", "abdominais"] }
      ]
    },
    {
      id: "fb_3",
      label: "Full Body A / B / C (3x/sem)",
      dias: [
        { nome: "Dia 1 · Full Body A", grupos: ["quadriceps", "peito", "dorsais", "ombros", "abdominais"] },
        { nome: "Dia 2 · Full Body B", grupos: ["isquiotibiais", "gluteos", "meio-das-costas", "biceps", "triceps"] },
        { nome: "Dia 3 · Full Body C", grupos: ["quadriceps", "peito", "dorsais", "panturrilhas", "abdominais"] }
      ]
    },
    {
      id: "abc_trad_3",
      label: "ABC Clássico (Peito/Tríceps · Costas/Bíceps · Pernas/Ombro)",
      dias: [
        { nome: "Dia 1 · Peito & Tríceps", grupos: ["peito", "triceps", "abdominais"] },
        { nome: "Dia 2 · Costas & Bíceps", grupos: ["dorsais", "meio-das-costas", "biceps"] },
        { nome: "Dia 3 · Pernas & Ombros", grupos: ["quadriceps", "isquiotibiais", "gluteos", "ombros", "panturrilhas"] }
      ]
    }
  ],
  4: [
    {
      id: "ul_4",
      label: "Upper / Lower AB x2 (Superiores & Inferiores 2x)",
      dias: [
        { nome: "Dia 1 · Superiores A (Força/Base)", grupos: ["peito", "dorsais", "ombros", "biceps", "triceps"] },
        { nome: "Dia 2 · Inferiores A (Foco Quadríceps)", grupos: ["quadriceps", "isquiotibiais", "gluteos", "panturrilhas", "abdominais"] },
        { nome: "Dia 3 · Superiores B (Volume/Costas)", grupos: ["meio-das-costas", "peito", "ombros", "triceps", "biceps"] },
        { nome: "Dia 4 · Inferiores B (Foco Posterior/Glúteo)", grupos: ["isquiotibiais", "gluteos", "quadriceps", "panturrilhas", "abdominais"] }
      ]
    },
    {
      id: "abcd_4",
      label: "ABCD Segmentado (1 Grupo Grande por Dia)",
      dias: [
        { nome: "Dia 1 · Peito & Abdômen", grupos: ["peito", "abdominais"] },
        { nome: "Dia 2 · Costas & Trapézio", grupos: ["dorsais", "meio-das-costas", "trapezio"] },
        { nome: "Dia 3 · Pernas Completas", grupos: ["quadriceps", "isquiotibiais", "gluteos", "panturrilhas"] },
        { nome: "Dia 4 · Ombros & Braços", grupos: ["ombros", "biceps", "triceps"] }
      ]
    }
  ],
  5: [
    {
      id: "ppl_ul_5",
      label: "PPL + Upper/Lower (Híbrido 5x)",
      dias: [
        { nome: "Dia 1 · Push (Peito, Ombro, Tríceps)", grupos: ["peito", "ombros", "triceps"] },
        { nome: "Dia 2 · Pull (Costas, Bíceps)", grupos: ["dorsais", "meio-das-costas", "biceps"] },
        { nome: "Dia 3 · Legs (Pernas Completas)", grupos: ["quadriceps", "isquiotibiais", "gluteos", "panturrilhas"] },
        { nome: "Dia 4 · Upper (Superiores Completo)", grupos: ["peito", "dorsais", "ombros", "biceps", "triceps"] },
        { nome: "Dia 5 · Lower & Core (Inferiores + Abd)", grupos: ["quadriceps", "isquiotibiais", "gluteos", "abdominais"] }
      ]
    },
    {
      id: "abcde_5",
      label: "ABCDE Bodybuilding (1 Grupamento/Dia)",
      dias: [
        { nome: "Dia 1 · Peitoral", grupos: ["peito", "abdominais"] },
        { nome: "Dia 2 · Dorsais & Costas", grupos: ["dorsais", "meio-das-costas", "inferior-das-costas"] },
        { nome: "Dia 3 · Quadríceps & Panturrilhas", grupos: ["quadriceps", "panturrilhas"] },
        { nome: "Dia 4 · Ombros & Core", grupos: ["ombros", "trapezio", "abdominais"] },
        { nome: "Dia 5 · Posteriores, Glúteos & Braços", grupos: ["isquiotibiais", "gluteos", "biceps", "triceps"] }
      ]
    }
  ],
  6: [
    {
      id: "ppl_6",
      label: "Push / Pull / Legs x2 (ABC 2x)",
      dias: [
        { nome: "Dia 1 · Push A (Foco Peitoral)", grupos: ["peito", "ombros", "triceps"] },
        { nome: "Dia 2 · Pull A (Foco Largura Dorsal)", grupos: ["dorsais", "meio-das-costas", "biceps"] },
        { nome: "Dia 3 · Legs A (Foco Quadríceps)", grupos: ["quadriceps", "isquiotibiais", "gluteos", "panturrilhas"] },
        { nome: "Dia 4 · Push B (Foco Ombros)", grupos: ["ombros", "peito", "triceps", "abdominais"] },
        { nome: "Dia 5 · Pull B (Foco Espessura Costas)", grupos: ["meio-das-costas", "dorsais", "biceps", "antebracos"] },
        { nome: "Dia 6 · Legs B (Foco Posterior/Glúteo)", grupos: ["isquiotibiais", "gluteos", "quadriceps", "panturrilhas", "abdominais"] }
      ]
    },
    {
      id: "ul_6",
      label: "Upper / Lower x3 (Alta Frequência)",
      dias: [
        { nome: "Dia 1 · Upper 1", grupos: ["peito", "dorsais", "ombros", "biceps", "triceps"] },
        { nome: "Dia 2 · Lower 1", grupos: ["quadriceps", "isquiotibiais", "gluteos", "panturrilhas"] },
        { nome: "Dia 3 · Upper 2", grupos: ["meio-das-costas", "peito", "ombros", "triceps", "biceps"] },
        { nome: "Dia 4 · Lower 2", grupos: ["isquiotibiais", "gluteos", "quadriceps", "abdominais"] },
        { nome: "Dia 5 · Upper 3", grupos: ["peito", "dorsais", "ombros", "biceps", "triceps"] },
        { nome: "Dia 6 · Lower 3", grupos: ["quadriceps", "isquiotibiais", "gluteos", "panturrilhas", "abdominais"] }
      ]
    }
  ],
  7: [
    {
      id: "ppl_6_active_7",
      label: "PPL x2 + Dia 7 Core, Mobilidade & Pontos Fracos",
      dias: [
        { nome: "Dia 1 · Push A", grupos: ["peito", "ombros", "triceps"] },
        { nome: "Dia 2 · Pull A", grupos: ["dorsais", "meio-das-costas", "biceps"] },
        { nome: "Dia 3 · Legs A", grupos: ["quadriceps", "isquiotibiais", "gluteos", "panturrilhas"] },
        { nome: "Dia 4 · Push B", grupos: ["ombros", "peito", "triceps"] },
        { nome: "Dia 5 · Pull B", grupos: ["meio-das-costas", "dorsais", "biceps"] },
        { nome: "Dia 6 · Legs B", grupos: ["isquiotibiais", "gluteos", "quadriceps", "panturrilhas"] },
        { nome: "Dia 7 · Core, Postura & Pontos Fracos", grupos: ["abdominais", "ombros", "panturrilhas", "antebracos"] }
      ]
    },
    {
      id: "abcde_plus_7",
      label: "ABCDE + 2 Dias de Reforço / Metabólico",
      dias: [
        { nome: "Dia 1 · Peito & Core", grupos: ["peito", "abdominais"] },
        { nome: "Dia 2 · Costas", grupos: ["dorsais", "meio-das-costas"] },
        { nome: "Dia 3 · Quadríceps", grupos: ["quadriceps", "panturrilhas"] },
        { nome: "Dia 4 · Ombros & Trapézio", grupos: ["ombros", "trapezio"] },
        { nome: "Dia 5 · Posterior & Glúteo", grupos: ["isquiotibiais", "gluteos"] },
        { nome: "Dia 6 · Braços (Bíceps/Tríceps/Antebraço)", grupos: ["biceps", "triceps", "antebracos"] },
        { nome: "Dia 7 · Full Body Metabólico & Core", grupos: ["quadriceps", "peito", "dorsais", "abdominais"] }
      ]
    }
  ]
};

// Mapeamento das 4 categorias de equipamento solicitadas para os slugs reais do JSON
const MAPA_MODALIDADE_EQUIP = {
  maquina: ["maquina", "cabo"],
  livre: ["barra", "halteres", "barra-w"],
  acessorio: ["kettlebell", "faixas", "bola-de-exercicio", "bola-medicinal", "rolo-de-espuma", "outros"],
  corporal: ["peso-do-corpo", null]
};

const PRESCRICAO_OBJETIVO = {
  forca: { seriesComposto: 4, seriesIsolado: 3, reps: "4–6", descansoSec: 150, cadencia: "2-1-X-0", rir: "RIR 1–2" },
  hipertrofia: { seriesComposto: 4, seriesIsolado: 3, reps: "8–12", descansoSec: 75, cadencia: "3-0-1-0", rir: "RIR 1–2" },
  resistencia: { seriesComposto: 3, seriesIsolado: 3, reps: "15–20", descansoSec: 45, cadencia: "2-0-2-0", rir: "RIR 2–3" },
  emagrecimento: { seriesComposto: 3, seriesIsolado: 3, reps: "12–15", descansoSec: 40, cadencia: "2-0-1-0", rir: "RIR 2" }
};

const MUSCULO_LABEL = {
  peito: "Peitoral",
  dorsais: "Dorsais",
  "meio-das-costas": "Costas (Médio)",
  "inferior-das-costas": "Lombar",
  ombros: "Ombros",
  biceps: "Bíceps",
  triceps: "Tríceps",
  antebracos: "Antebraços",
  quadriceps: "Quadríceps",
  isquiotibiais: "Posteriores",
  gluteos: "Glúteos",
  panturrilhas: "Panturrilhas",
  abdominais: "Abdômen",
  adutores: "Adutores",
  abdutores: "Abdutores",
  trapezio: "Trapézio"
};

let bancoExercicios = [];
let planoAtual = [];
let perfilAtual = null;
let abaAtiva = 0;
let cargasSalvas = JSON.parse(localStorage.getItem("treinospro_v2_cargas") || "{}");
let seriesConcluidas = JSON.parse(localStorage.getItem("treinospro_v2_checks") || "{}");

// Cronômetro
let timerInterval = null;
let timerRestante = 0;

document.addEventListener("DOMContentLoaded", async () => {
  registrarSW();
  await carregarBancoExercicios();

  const diasSelect = document.getElementById("dias");
  diasSelect.addEventListener("change", () => atualizarOpcoesDivisao());

  const planoSalvo = localStorage.getItem("treinospro_v2_plano");
  const perfilSalvo = localStorage.getItem("treinospro_v2_perfil");

  if (perfilSalvo) {
    perfilAtual = JSON.parse(perfilSalvo);
    preencherFormulario(perfilAtual);
  } else {
    atualizarOpcoesDivisao();
  }

  if (planoSalvo && perfilAtual) {
    planoAtual = JSON.parse(planoSalvo);
    renderizarPlano();
  }

  document.getElementById("form-gerador").addEventListener("submit", (e) => {
    e.preventDefault();
    gerarNovoPlano();
  });

  document.getElementById("json-upload").addEventListener("change", importarJsonManual);
});

function registrarSW() {
  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("./sw.js").catch(() => {});
  }
}

async function carregarBancoExercicios() {
  const badge = document.getElementById("db-status");
  const cachedJson = localStorage.getItem("treinospro_custom_db");
  if (cachedJson) {
    try {
      const parsed = JSON.parse(cachedJson);
      if (Array.isArray(parsed) && parsed.length > 0) {
        bancoExercicios = parsed;
        badge.textContent = `Banco Completo (${bancoExercicios.length} ex.)`;
        badge.className = "text-xs px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30";
        return;
      }
    } catch (_) {}
  }

  try {
    const resp = await fetch("./exercises-ptbr-full-translation.json");
    if (resp.ok) {
      const data = await resp.json();
      if (Array.isArray(data) && data.length > 0) {
        bancoExercicios = data;
        badge.textContent = `JSON Carregado (${bancoExercicios.length} ex.)`;
        badge.className = "text-xs px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30";
        return;
      }
    }
  } catch (_) {}

  bancoExercicios = FALLBACK_EXERCISES;
  badge.textContent = `Modo Demo (${bancoExercicios.length} ex. · Importe JSON)`;
  badge.className = "text-xs px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30";
}

function importarJsonManual(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const data = JSON.parse(e.target.result);
      if (!Array.isArray(data) || !data[0]?.name || !data[0]?.primaryMuscles) {
        alert("Formato inválido. Selecione o arquivo exercises-ptbr-full-translation.json.");
        return;
      }
      bancoExercicios = data;
      localStorage.setItem("treinospro_custom_db", JSON.stringify(data));
      const badge = document.getElementById("db-status");
      badge.textContent = `JSON Importado (${bancoExercicios.length} ex.)`;
      badge.className = "text-xs px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30";
      alert(`Sucesso! ${bancoExercicios.length} exercícios carregados.`);
    } catch (err) {
      alert("Erro ao ler o JSON: " + err.message);
    }
  };
  reader.readAsText(file);
}

// Atualiza as opções de divisão e a prévia dia a dia sempre que mudar de 1 a 7 dias
function atualizarOpcoesDivisao(divisaoSelecionadaId = null) {
  const dias = parseInt(document.getElementById("dias").value, 10) || 3;
  const selectDiv = document.getElementById("modelo-divisao");
  const opcoes = MODELOS_DIVISAO[dias] || MODELOS_DIVISAO[3];

  selectDiv.innerHTML = opcoes
    .map((op) => `<option value="${op.id}" ${op.id === divisaoSelecionadaId ? "selected" : ""}>${op.label}</option>`)
    .join("");

  selectDiv.onchange = () => renderizarPreviaDivisao();
  renderizarPreviaDivisao();
}

function renderizarPreviaDivisao() {
  const dias = parseInt(document.getElementById("dias").value, 10) || 3;
  const divId = document.getElementById("modelo-divisao").value;
  const opcoes = MODELOS_DIVISAO[dias] || MODELOS_DIVISAO[3];
  const escolhida = opcoes.find((o) => o.id === divId) || opcoes[0];
  const previewEl = document.getElementById("previa-divisao");

  previewEl.innerHTML = escolhida.dias
    .map((d) => {
      const gruposTxt = d.grupos.map((g) => MUSCULO_LABEL[g] || g).join(" · ");
      return `<div class="flex items-center justify-between gap-2 text-xs py-1.5 px-2.5 rounded-lg bg-zinc-950/80 border border-zinc-800/80">
        <span class="font-bold text-emerald-400 shrink-0">${d.nome}</span>
        <span class="text-zinc-400 truncate">${gruposTxt}</span>
      </div>`;
    })
    .join("");
}

function niveisPermitidos(nivel) {
  if (nivel === "iniciante") return ["iniciante"];
  if (nivel === "intermediario") return ["iniciante", "intermediario"];
  return ["iniciante", "intermediario", "avancado"];
}

function lerFormulario() {
  const modalidades = Array.from(document.querySelectorAll('input[name="modalidade"]:checked')).map((el) => el.value);
  const evitarChecks = Array.from(document.querySelectorAll('input[name="evitar"]:checked')).map((el) => el.value);

  return {
    alunoNome: document.getElementById("aluno-nome").value.trim() || "Aluno",
    objetivo: document.getElementById("objetivo").value,
    nivel: document.getElementById("nivel").value,
    diasSemana: parseInt(document.getElementById("dias").value, 10),
    modeloDivisaoId: document.getElementById("modelo-divisao").value,
    tempoMinutos: parseInt(document.getElementById("tempo").value, 10),
    modalidades: modalidades.length ? modalidades : ["maquina", "livre", "acessorio", "corporal"],
    focoMuscular: document.getElementById("foco-muscular").value,
    metodologia: document.getElementById("metodologia").value,
    incluirAquecimento: document.getElementById("incluir-aquecimento").checked,
    musculosEvitar: evitarChecks
  };
}

function preencherFormulario(p) {
  if (!p) return;
  document.getElementById("aluno-nome").value = p.alunoNome || "";
  document.getElementById("objetivo").value = p.objetivo || "hipertrofia";
  document.getElementById("nivel").value = p.nivel || "iniciante";
  document.getElementById("dias").value = String(p.diasSemana || 3);
  atualizarOpcoesDivisao(p.modeloDivisaoId);
  document.getElementById("tempo").value = String(p.tempoMinutos || 60);
  document.getElementById("foco-muscular").value = p.focoMuscular || "";
  document.getElementById("metodologia").value = p.metodologia || "tradicional";
  document.getElementById("incluir-aquecimento").checked = !!p.incluirAquecimento;

  document.querySelectorAll('input[name="modalidade"]').forEach((cb) => {
    cb.checked = (p.modalidades || []).includes(cb.value);
  });
  document.querySelectorAll('input[name="evitar"]').forEach((cb) => {
    cb.checked = (p.musculosEvitar || []).includes(cb.value);
  });
}

function obterEquipamentosPermitidos(modalidades) {
  const lista = [];
  modalidades.forEach((mod) => {
    const eqs = MAPA_MODALIDADE_EQUIP[mod] || [];
    lista.push(...eqs);
  });
  return lista;
}

function rotuloModalidade(equipment) {
  if (MAPA_MODALIDADE_EQUIP.maquina.includes(equipment)) return "Máquina / Polia";
  if (MAPA_MODALIDADE_EQUIP.livre.includes(equipment)) return "Peso Livre";
  if (MAPA_MODALIDADE_EQUIP.acessorio.includes(equipment)) return "Acessório";
  return "Peso do Corpo";
}

function gerarNovoPlano() {
  perfilAtual = lerFormulario();
  const niveis = niveisPermitidos(perfilAtual.nivel);
  const equipsPermitidos = obterEquipamentosPermitidos(perfilAtual.modalidades);
  const configObj = PRESCRICAO_OBJETIVO[perfilAtual.objetivo] || PRESCRICAO_OBJETIVO.hipertrofia;
  const maxExerciciosDia = perfilAtual.tempoMinutos <= 35 ? 4 : perfilAtual.tempoMinutos <= 50 ? 6 : 8;

  // Filtra exercícios principais (força / powerlifting)
  const bancoFiltrado = bancoExercicios.filter((ex) => {
    const catOk = ex.category === "forca" || (perfilAtual.nivel === "avancado" && ex.category === "powerlifting");
    const nivelOk = niveis.includes(ex.level);
    const equipOk = equipsPermitidos.includes(ex.equipment);
    const semRestricao = !(ex.primaryMuscles || []).some((m) => perfilAtual.musculosEvitar.includes(m));
    return catOk && nivelOk && equipOk && semRestricao;
  });

  // Banco opcional de mobilidade/alongamento para aquecimento
  const bancoMobilidade = bancoExercicios.filter(
    (ex) => ex.category === "alongamento" && (ex.equipment === null || ex.equipment === "peso-do-corpo" || equipsPermitidos.includes(ex.equipment))
  );

  const opcoesDiv = MODELOS_DIVISAO[perfilAtual.diasSemana] || MODELOS_DIVISAO[3];
  const divisaoEscolhida = opcoesDiv.find((o) => o.id === perfilAtual.modeloDivisaoId) || opcoesDiv[0];
  const usadosNaSemana = new Set();

  planoAtual = divisaoEscolhida.dias.map((dia) => {
    let selecionados = [];
    const gruposDia = [...dia.grupos];

    // Se houver prioridade muscular e ela fizer parte do dia (ou em dias Full Body), ganha cota extra
    const temFocoHoje = perfilAtual.focoMuscular && gruposDia.includes(perfilAtual.focoMuscular);
    const porGrupoBase = Math.max(1, Math.floor(maxExerciciosDia / gruposDia.length));

    gruposDia.forEach((grupo) => {
      const cotaGrupo = temFocoHoje && grupo === perfilAtual.focoMuscular ? porGrupoBase + 1 : porGrupoBase;

      let candidatos = bancoFiltrado.filter(
        (ex) => (ex.primaryMuscles || []).includes(grupo) && !usadosNaSemana.has(ex.id)
      );

      if (candidatos.length === 0) {
        candidatos = bancoFiltrado.filter((ex) => (ex.primaryMuscles || []).includes(grupo));
      }

      const embaralhados = [...candidatos].sort(() => Math.random() - 0.5);
      const compostos = embaralhados.filter((e) => e.mechanic === "composto");
      const isolados = embaralhados.filter((e) => e.mechanic !== "composto");
      const escolhidos = [...compostos, ...isolados].slice(0, cotaGrupo);

      escolhidos.forEach((ex) => {
        usadosNaSemana.add(ex.id);
        selecionados.push(ex);
      });
    });

    // Completa vagas restantes respeitando os grupos do dia
    if (selecionados.length < maxExerciciosDia) {
      const extras = bancoFiltrado
        .filter(
          (ex) =>
            !selecionados.some((s) => s.id === ex.id) &&
            (ex.primaryMuscles || []).some((m) => gruposDia.includes(m))
        )
        .sort(() => Math.random() - 0.5)
        .slice(0, maxExerciciosDia - selecionados.length);
      selecionados = [...selecionados, ...extras];
    }

    // Ordenação biomecânica: Prioridade (se pré-exaustão) -> Compostos -> Isolados -> Abdômen/Panturrilhas
    selecionados = selecionados
      .slice(0, maxExerciciosDia)
      .sort((a, b) => {
        const coreA = a.primaryMuscles.includes("abdominais") || a.primaryMuscles.includes("panturrilhas");
        const coreB = b.primaryMuscles.includes("abdominais") || b.primaryMuscles.includes("panturrilhas");
        if (coreA && !coreB) return 1;
        if (!coreA && coreB) return -1;
        if (a.mechanic === "composto" && b.mechanic !== "composto") return -1;
        if (a.mechanic !== "composto" && b.mechanic === "composto") return 1;
        return 0;
      })
      .map((ex, index) => {
        const isComposto = ex.mechanic === "composto";
        const isFoco = perfilAtual.focoMuscular && (ex.primaryMuscles || []).includes(perfilAtual.focoMuscular);
        let series = isComposto ? configObj.seriesComposto : configObj.seriesIsolado;
        if (isFoco) series += 1; // +1 série no músculo prioritário

        let tecnica = "Séries Tradicionais";
        if (perfilAtual.metodologia === "biset" && !isComposto && index > 0) {
          tecnica = "Bi-Set / Conjugado";
        } else if (perfilAtual.metodologia === "piramide" && isComposto) {
          tecnica = "Pirâmide Crescente (12/10/8/6)";
        } else if (perfilAtual.metodologia === "restpause" && !isComposto) {
          tecnica = "Rest-Pause na última série";
        }

        return {
          ...ex,
          prescricao: {
            series,
            repeticoes: perfilAtual.metodologia === "piramide" && isComposto ? "12-10-8-6" : configObj.reps,
            descansoSec: isComposto ? configObj.descansoSec : 60,
            cadencia: configObj.cadencia,
            rir: configObj.rir,
            tecnica,
            isFoco
          }
        };
      });

    // Opcional: 2 exercícios de mobilidade/aquecimento específicos para os grupos do dia
    let aquecimento = [];
    if (perfilAtual.incluirAquecimento && bancoMobilidade.length > 0) {
      aquecimento = bancoMobilidade
        .filter((ex) => (ex.primaryMuscles || []).some((m) => gruposDia.includes(m)))
        .sort(() => Math.random() - 0.5)
        .slice(0, 2);
    }

    return {
      titulo: dia.nome,
      grupos: gruposDia,
      aquecimento,
      exercicios: selecionados
    };
  });

  abaAtiva = 0;
  seriesConcluidas = {};
  localStorage.setItem("treinospro_v2_checks", JSON.stringify(seriesConcluidas));
  localStorage.setItem("treinospro_v2_plano", JSON.stringify(planoAtual));
  localStorage.setItem("treinospro_v2_perfil", JSON.stringify(perfilAtual));

  renderizarPlano();
}

function trocarExercicio(diaIdx, exIdx) {
  const atual = planoAtual[diaIdx].exercicios[exIdx];
  const niveis = niveisPermitidos(perfilAtual.nivel);
  const equipsPermitidos = obterEquipamentosPermitidos(perfilAtual.modalidades);
  const idsNoDia = new Set(planoAtual[diaIdx].exercicios.map((e) => e.id));

  const candidatos = bancoExercicios.filter(
    (ex) =>
      !idsNoDia.has(ex.id) &&
      (ex.category === "forca" || ex.category === "powerlifting") &&
      niveis.includes(ex.level) &&
      equipsPermitidos.includes(ex.equipment) &&
      (ex.primaryMuscles || []).some((m) => (atual.primaryMuscles || []).includes(m))
  );

  if (candidatos.length === 0) {
    alert("Não há outro exercício equivalente com os equipamentos selecionados.");
    return;
  }

  const novo = candidatos[Math.floor(Math.random() * candidatos.length)];
  planoAtual[diaIdx].exercicios[exIdx] = {
    ...novo,
    prescricao: atual.prescricao
  };

  localStorage.setItem("treinospro_v2_plano", JSON.stringify(planoAtual));
  renderizarPlano();
}

function salvarCarga(exId, valor) {
  cargasSalvas[exId] = valor;
  localStorage.setItem("treinospro_v2_cargas", JSON.stringify(cargasSalvas));
}

function toggleSerie(chave, descansoSec) {
  seriesConcluidas[chave] = !seriesConcluidas[chave];
  localStorage.setItem("treinospro_v2_checks", JSON.stringify(seriesConcluidas));
  renderizarPlano();

  if (seriesConcluidas[chave]) {
    iniciarTimer(descansoSec);
  }
}

function renderizarPlano() {
  const sec = document.getElementById("resultado-treino");
  if (!planoAtual || planoAtual.length === 0) {
    sec.classList.add("hidden");
    return;
  }

  sec.classList.remove("hidden");
  const modsTxt = (perfilAtual.modalidades || []).join(", ");
  document.getElementById("resumo-aluno").textContent =
    `${perfilAtual.alunoNome} · ${perfilAtual.diasSemana}x/sem · ${perfilAtual.objetivo.toUpperCase()} (${perfilAtual.nivel}) · Equip: ${modsTxt}`;

  const tabsEl = document.getElementById("tabs-dias");
  tabsEl.innerHTML = planoAtual
    .map((dia, idx) => {
      const ativo = idx === abaAtiva;
      return `<button onclick="selecionarAba(${idx})" class="px-4 py-2.5 rounded-xl text-sm font-semibold whitespace-nowrap transition ${
        ativo
          ? "bg-emerald-500 text-zinc-950 shadow-lg shadow-emerald-500/20"
          : "bg-zinc-900 text-zinc-300 border border-zinc-800 hover:border-zinc-700"
      }">${dia.titulo}</button>`;
    })
    .join("");

  const dia = planoAtual[abaAtiva];
  const listaEl = document.getElementById("lista-exercicios");

  if (!dia || dia.exercicios.length === 0) {
    listaEl.innerHTML = `<div class="p-6 bg-zinc-900 rounded-2xl border border-zinc-800 text-zinc-400">Nenhum exercício encontrado para os filtros marcados. Tente selecionar mais tipos de equipamento (Máquina, Livre, Acessório ou Peso do Corpo).</div>`;
    return;
  }

  let htmlAquecimento = "";
  if (dia.aquecimento && dia.aquecimento.length > 0) {
    htmlAquecimento = `
      <div class="bg-sky-950/30 border border-sky-500/30 rounded-2xl p-4 space-y-2">
        <div class="flex items-center justify-between">
          <span class="text-xs font-extrabold uppercase tracking-wider text-sky-400">Aquecimento & Mobilidade Articular (5 min)</span>
          <span class="text-[11px] text-sky-300/80">1–2 séries de 15–20s / 10 reps</span>
        </div>
        <div class="space-y-1.5">
          ${dia.aquecimento.map((aq, i) => `
            <div class="flex items-center justify-between text-sm text-zinc-200 bg-zinc-950/60 px-3 py-2 rounded-xl">
              <span>• ${aq.name}</span>
              <button onclick="abrirInstrucoesAquecimento(${abaAtiva}, ${i})" class="text-xs text-sky-400 font-semibold">Ver</button>
            </div>
          `).join("")}
        </div>
      </div>`;
  }

  const cardsHtml = dia.exercicios
    .map((ex, idx) => {
      const musculos = (ex.primaryMuscles || []).map((m) => MUSCULO_LABEL[m] || m).join(", ");
      const modalidadeBadge = rotuloModalidade(ex.equipment);
      const equipDetalhe = ex.equipment ? ex.equipment.replace(/-/g, " ") : "sem equipamento";
      const carga = cargasSalvas[ex.id] || "";

      let checksHtml = "";
      for (let s = 1; s <= ex.prescricao.series; s++) {
        const chave = `${abaAtiva}_${ex.id}_s${s}`;
        const feito = !!seriesConcluidas[chave];
        checksHtml += `<button onclick="toggleSerie('${chave}', ${ex.prescricao.descansoSec})" class="h-11 flex-1 rounded-xl font-bold text-sm border transition ${
          feito
            ? "bg-emerald-500 border-emerald-400 text-zinc-950"
            : "bg-zinc-950 border-zinc-700 text-zinc-300 hover:border-emerald-500/60"
        }">S${s} ${feito ? "✓" : ""}</button>`;
      }

      return `
      <article class="bg-zinc-900 border ${ex.prescricao.isFoco ? "border-emerald-500/50" : "border-zinc-800"} rounded-2xl p-4 sm:p-5 space-y-3.5">
        <div class="flex items-start justify-between gap-3">
          <div>
            <div class="flex flex-wrap items-center gap-1.5 mb-1.5">
              <span class="text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-400">${musculos}</span>
              <span class="text-xs px-2 py-0.5 rounded bg-indigo-500/15 text-indigo-300 border border-indigo-500/20 font-medium">${modalidadeBadge} (${equipDetalhe})</span>
              ${ex.prescricao.isFoco ? `<span class="text-xs px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold">★ Prioridade</span>` : ""}
            </div>
            <h3 class="text-lg font-bold text-white leading-snug">${idx + 1}. ${ex.name}</h3>
            <p class="text-xs text-zinc-400 mt-0.5">${ex.prescricao.tecnica} · Cadência ${ex.prescricao.cadencia} · ${ex.prescricao.rir}</p>
          </div>
          <div class="flex items-center gap-1.5 shrink-0">
            <button onclick="abrirInstrucoes(${abaAtiva}, ${idx})" class="px-3 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-200">Execução</button>
            <button onclick="trocarExercicio(${abaAtiva}, ${idx})" class="px-3 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-amber-300">↻ Trocar</button>
          </div>
        </div>

        <div class="grid grid-cols-3 gap-2 bg-zinc-950/70 p-3 rounded-xl border border-zinc-800/80 text-center">
          <div>
            <span class="block text-[11px] uppercase text-zinc-500">Séries × Reps</span>
            <span class="text-base font-bold text-white">${ex.prescricao.series} × ${ex.prescricao.repeticoes}</span>
          </div>
          <div>
            <span class="block text-[11px] uppercase text-zinc-500">Descanso</span>
            <button onclick="iniciarTimer(${ex.prescricao.descansoSec})" class="text-base font-bold text-emerald-400 underline decoration-dotted">${ex.prescricao.descansoSec}s ⏱</button>
          </div>
          <div>
            <span class="block text-[11px] uppercase text-zinc-500">Carga (kg)</span>
            <input type="text" value="${carga}" onchange="salvarCarga('${ex.id}', this.value)" placeholder="Ex: 20kg" class="w-full text-center bg-zinc-900 border border-zinc-700 rounded-lg text-sm font-semibold text-white py-0.5 focus:outline-none focus:border-emerald-500" />
          </div>
        </div>

        <div class="flex items-center gap-2">
          ${checksHtml}
        </div>
      </article>`;
    })
    .join("");

  listaEl.innerHTML = htmlAquecimento + cardsHtml;
}

function selecionarAba(idx) {
  abaAtiva = idx;
  renderizarPlano();
}

function abrirInstrucoes(diaIdx, exIdx) {
  const ex = planoAtual[diaIdx].exercicios[exIdx];
  exibirModalExercicio(ex);
}

function abrirInstrucoesAquecimento(diaIdx, aqIdx) {
  const ex = planoAtual[diaIdx].aquecimento[aqIdx];
  exibirModalExercicio(ex);
}

function exibirModalExercicio(ex) {
  document.getElementById("modal-titulo").textContent = ex.name;
  const passos = (ex.instructions && ex.instructions.length > 0)
    ? ex.instructions.map((p, i) => `<li class="flex gap-2.5"><span class="font-bold text-emerald-400">${i + 1}.</span><span>${p}</span></li>`).join("")
    : `<li class="text-zinc-400">Sem instruções detalhadas cadastradas para este exercício.</li>`;

  document.getElementById("modal-conteudo").innerHTML = `<ol class="space-y-2.5 text-sm text-zinc-200 leading-relaxed">${passos}</ol>`;
  document.getElementById("modal-instrucoes").classList.remove("hidden");
  document.getElementById("modal-instrucoes").classList.add("flex");
}

function fecharModal() {
  document.getElementById("modal-instrucoes").classList.add("hidden");
  document.getElementById("modal-instrucoes").classList.remove("flex");
}

function tocarBip() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(880, ctx.currentTime);
    gain.gain.setValueAtTime(0.2, ctx.currentTime);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.25);
  } catch (_) {}
}

function iniciarTimer(segundos) {
  clearInterval(timerInterval);
  timerRestante = segundos;
  const bar = document.getElementById("timer-bar");
  bar.classList.remove("hidden");
  atualizarDisplayTimer();

  timerInterval = setInterval(() => {
    timerRestante--;
    atualizarDisplayTimer();
    if (timerRestante <= 0) {
      clearInterval(timerInterval);
      tocarBip();
      document.getElementById("timer-display").textContent = "PRONTO!";
    }
  }, 1000);
}

function atualizarDisplayTimer() {
  const min = String(Math.floor(Math.max(0, timerRestante) / 60)).padStart(2, "0");
  const sec = String(Math.max(0, timerRestante) % 60).padStart(2, "0");
  document.getElementById("timer-display").textContent = `${min}:${sec}`;
}

function pararTimer() {
  clearInterval(timerInterval);
  document.getElementById("timer-bar").classList.add("hidden");
}

function copiarFichaTexto() {
  if (!planoAtual.length) return;
  let texto = `*FICHA DE TREINO - ${perfilAtual.alunoNome.toUpperCase()}*\n`;
  texto += `Objetivo: ${perfilAtual.objetivo} | Nível: ${perfilAtual.nivel} | Freq: ${perfilAtual.diasSemana}x/sem\n\n`;

  planoAtual.forEach((dia) => {
    texto += `*${dia.titulo.toUpperCase()}*\n`;
    if (dia.aquecimento && dia.aquecimento.length) {
      texto += `_Aquecimento:_ ${dia.aquecimento.map((a) => a.name).join(", ")}\n`;
    }
    dia.exercicios.forEach((ex, i) => {
      const carga = cargasSalvas[ex.id] ? ` (${cargasSalvas[ex.id]})` : "";
      texto += `${i + 1}. ${ex.name} — ${ex.prescricao.series}x${ex.prescricao.repeticoes} | Desc: ${ex.prescricao.descansoSec}s${carga}\n`;
    });
    texto += `\n`;
  });

  navigator.clipboard.writeText(texto).then(() => {
    alert("Ficha copiada! Cole diretamente no WhatsApp do aluno.");
  });
}
